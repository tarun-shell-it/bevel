require('dotenv').config();
const Web3 = require('web3');
const fs = require('fs');
var bodyParser = require('body-parser');
// Connect to Besu Node
const web3 = new Web3(process.env.STORE_RPC);

// Load the Contract ABI and Contract Address
const contractAbi = JSON.parse(fs.readFileSync(process.env.ABI_PATH, 'utf8')); 
const contractAddress = process.env.CONTRACT_ADDR;

// Define which node is calling the function
const fromAddress = process.env.STORE_ADDR;
// Since this is just a read function, we do not need to set the private key value


// Initialize the Contract Instance
const contract = new web3.eth.Contract(contractAbi, contractAddress);

// Get containers chocolate bars
async function getProducts(){
    let productCount;
    let productsArray = [];
    contract.methods
        .getProductsLength()
        .call({ from: fromAddress, gas: 6721975, gasPrice: "0" })
        .then(async response => {
            productCount = response;
            console.log("LENGTH ", response);
            for (var i = 1; i <= productCount; i++) {
                var toPush = await contract.methods
                    .getProductAt(i)
                    .call({ from: fromAddress, gas: 6721975, gasPrice: "0" })
                var product = {};
                if (toPush.trackingID != 0) {
                    product.trackingID = toPush.trackingID;
                    product.productName = toPush.productName;
                    product.health = toPush.health;
                    product.sold = toPush.sold;
                    product.recalled = toPush.recalled;
                    product.custodian = toPush.custodian;
                    product.custodian = product.custodian + "," + toPush.lastScannedAt;
                    product.time  = (new Date(toPush.timestamp * 1000)).getTime();
                    product.lastScannedAt = toPush.lastScannedAt;
                    product.containerID = toPush.containerID;
                    product.misc = toPush.misc;
                    product.linearId = {
                        "externalId": null,
                        "id": toPush.trackingID
                    };
                    product.participants = toPush.participants;
                    productsArray.push(product);
                }
            }
            console.log(productsArray)
        })
    };

// Execute function
getProducts();