require('dotenv').config();
const Web3 = require('web3');
const fs = require('fs');
var bodyParser = require('body-parser');
// Connect to Besu Node
const web3 = new Web3(process.env.STORE_RPC);

// Load the Contract ABI and Contract Address
const contractAbi = JSON.parse(fs.readFileSync(process.env.ABI_PATH, 'utf8'));
const contractAddress = process.env.CONTRACT_ADDR;

// Define which node is calling the function
const fromAddress = process.env.STORE_ADDR;

// Define product tracking ID of almond chocolate bar
let productTrackingID = process.env.ALMOND_TRACKING_ID;


// Initialize the Contract Instance
const contract = new web3.eth.Contract(contractAbi, contractAddress);

// Get almond chocolate bar given ID
async function getOneProduct(){
    contract.methods
        .getSingleProduct(productTrackingID)
        .call({ from: fromAddress, gas: 6721975, gasPrice: "0" })
        .then(async response => {
            let product = response;
            console.log(product);
            console.log(product.containerID);
        })
    };


getOneProduct();