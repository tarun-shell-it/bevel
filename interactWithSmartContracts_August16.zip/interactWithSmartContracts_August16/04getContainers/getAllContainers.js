require('dotenv').config();
const Web3 = require('web3');
const fs = require('fs');
var bodyParser = require('body-parser');
// Connect to Besu Node
const web3 = new Web3(process.env.CARRIER_RPC);

//  Load the Contract ABI and Address
const contractAbi = JSON.parse(fs.readFileSync(process.env.ABI_PATH, 'utf8'));
const contractAddress = process.env.CONTRACT_ADDR;

const fromAddress = process.env.CARRIER_ADDR;

// Initialize the Contract Instance
const contract = new web3.eth.Contract(contractAbi, contractAddress);

// Get containers 
async function getContainers(){
    let containerCount;
    let containerArray = [];
    contract.methods
        .getContainersLength()
        .call({ from: fromAddress, gas: 6721975, gasPrice: "0" })
        .then(async response => {
            containerCount = response;
            console.log("LENGTH ", response);
            for (var i = 1; i <= containerCount; i++) {
                var toPush = await contract.methods
                    .getContainerAt(i)
                    .call({ from: fromAddress, gas: 6721975, gasPrice: "0" })
                var container = {};
                if (toPush.trackingID != 0) {
                    container.health = toPush.health;
                    container.misc = toPush.misc;
                    container.trackingID = toPush.trackingID;
                    container.custodian = toPush.custodian;
                    container.custodian = container.custodian + "," + toPush.lastScannedAt;
                    container.time  = (new Date(toPush.timestamp * 1000)).getTime();
                    container.lastScannedAt = toPush.lastScannedAt;
                    container.containerID = toPush.containerID;
                    container.linearId = {
                        "externalId": null,
                        "id": toPush.trackingID
                    };
                    container.participants = toPush.participants;
                    container.containerContents = toPush.containerContents;
                    containerArray.push(container);
                }
            }
            console.log(containerArray)
        })
    };


getContainers();