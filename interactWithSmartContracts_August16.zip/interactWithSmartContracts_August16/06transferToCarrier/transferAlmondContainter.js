require('dotenv').config();
const Web3 = require('web3');
const fs = require('fs');
var bodyParser = require('body-parser');
// Connect to Besu Node
const web3 = new Web3(process.env.MANUFACTURER_RPC);

// Load the Contract ABI and Address
const contractAbi = JSON.parse(fs.readFileSync(process.env.ABI_PATH, 'utf8')); 
const contractAddress = process.env.CONTRACT_ADDR;
const contract = new web3.eth.Contract(contractAbi, contractAddress);
const fromAddress = process.env.CARRIER_ADDR;
const privateKey = process.env.CARRIER_KEY;

let trackingID = process.env.ALMOND_CONTAINER_ID;
let lastScannedAt = process.env.CARRIER;


const myData = contract.methods.updateContainerCustodian(trackingID, lastScannedAt).encodeABI();
web3.eth.getTransactionCount(fromAddress).then(txCount => {
  const txObject = {
    nonce: web3.utils.toHex(txCount),
    to: contractAddress,
    value: '0x00',
    gasLimit: web3.utils.toHex(2100000),
    gasPrice: web3.utils.toHex(web3.utils.toWei('0', 'gwei')),
    data: myData  
  }
  web3.eth.accounts.signTransaction(
    txObject,
    privateKey
  ).then(signedTx => {
    web3.eth.sendSignedTransaction(
      signedTx.rawTransaction
    ).then( receipt => {
      console.log({TransactionReceipt: receipt});
    })
    .catch(e => {
      console.error('Error while reclaiming the container: ', e);
    });
  })
});

web3.eth.getTransactionCount(fromAddress);